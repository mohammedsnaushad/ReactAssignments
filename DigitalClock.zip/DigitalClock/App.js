import React from 'react';
import './App.css';
import DigitalClock from './component/DigitalClock';

function App() {
  return (
    <div className="App">
    <DigitalClock />
    </div>
  );
}

export default App;
