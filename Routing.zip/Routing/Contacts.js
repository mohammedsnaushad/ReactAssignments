const Contacts = () => {
    return ( 
        <div className="Contacts">
            <h2>Welcome to Contact Page</h2>
        </div>
     );
}
 
export default Contacts;