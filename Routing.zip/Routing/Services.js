const Services = () => {
    return ( 
        <div className="Services">
            <h2>Welcome to Service Page</h2>
        </div>
     );
}
 
export default Services;