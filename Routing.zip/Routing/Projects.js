const Projects = () => {
    return (  
        <div className="Projects">
            <h2>Welcome to Projects Page</h2>
        </div>
    );
}
 
export default Projects;